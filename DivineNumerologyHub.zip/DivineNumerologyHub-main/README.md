# DivineNumerologyHub
![image](https://github.com/vovanhung-dev/DivineNumerologyHub/assets/67744712/c86413e4-11eb-49e7-b2e2-3f0ed694b929)

## Giới Thiệu

Dự án Thần Số Học là một trang web thú vị và hữu ích dành cho những người quan tâm đến thần số học. Thần số học là một hệ thống tin học học về các sự kiện và tính cách của con người dựa trên các số liệu và phân tích số học.

## Tính Năng Chính

### 1. Tra cứu Số Học Cá Nhân
- Người dùng có thể nhập ngày tháng năm sinh của họ để tính toán các số học cá nhân quan trọng như Số Con Đường, Số Mệnh và nhiều số học khác.
- Hiển thị thông tin chi tiết về ý nghĩa và tác động của từng số học cá nhân.

### 2. Horoscope Số Học
- Cung cấp thông tin về các sự kiện và cung hoàng đạo dựa trên thần số học.

### 3. Tư Vấn Số Học
- Người dùng có thể đặt câu hỏi hoặc yêu cầu tư vấn từ các chuyên gia số học.
- Hiển thị câu trả lời và lời khuyên từ các chuyên gia số học.

### 4. Bài Viết và Tài Liệu
- Chia sẻ các bài viết, hướng dẫn và tài liệu về thần số học.
- Cung cấp nguồn thông tin uy tín và đáng tin cậy về thần số học.

## Cài Đặt và Sử Dụng

1. **Clone Repository**

    ```shell
    git clone https://github.com/vovanhung-dev/DivineNumerologyHub.git
    ```

2. **Cài Đặt Dependencies**

    ```shell
    npm install
    ```

3. **Khởi chạy Ứng Dụng**

    ```shell
    npm start
    ```

4. **Truy cập Trang Web**

    Mở trình duyệt và truy cập `http://localhost:3000` để xem trang web.
