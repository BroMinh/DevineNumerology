import React, { useState, useEffect, useRef } from "react";
import "./detail.css";
import eventApi from "../../apis/eventApi";
import productApi from "../../apis/productApi";
import { useHistory, useParams } from 'react-router-dom';
import { LikeOutlined, DislikeOutlined, HeartOutlined } from '@ant-design/icons';
import { Col, Row, Button, Form, Spin, Input, Card, notification, Modal, BackTop, message, Avatar, Badge, Rate, List, Descriptions } from "antd";
import axiosClient from "../../apis/axiosClient";
import 'suneditor/dist/css/suneditor.min.css';
import SunEditor from 'suneditor-react';
const { TextArea } = Input;

const Detail = () => {
    const [description, setDescription] = useState('');
    const [lifePathInfo, setLifePathInfo] = useState(null);
    const [personalYear, setPersonalYear] = useState(null);
    const [karmicDebt, setKarmicDebt] = useState(null);
    const [lifePyramid, setLifePyramid] = useState(null);
    const [nameChart, setNameChart] = useState(null);
    const [dayChart, setDayChart] = useState(null);

    const queryParameters = new URLSearchParams(window.location.search);
    const fullName = { name: queryParameters.get("fullName") };
    const birthday = { birthDate: queryParameters.get("birthday") };



    useEffect(() => {
        (async () => {
            try {
                const response = await axiosClient.post('/calculate/search', birthday);
                console.log('API response:', response);

                const response2 = await axiosClient.post('/calculate/lifepath', fullName);
                console.log('API response:', response2);
                setLifePathInfo(response2);

                const response3 = await axiosClient.post('/calculate/personalYear', birthday);
                console.log('API response:', response3);
                setPersonalYear(response3)

                const response4 = await axiosClient.post('/calculate/karmicDebt', birthday);
                console.log('API response:', response4);
                setKarmicDebt(response4)

                const response5 = await axiosClient.post('/calculate/lifePyramid', birthday);
                console.log('API response:', response5);
                setLifePyramid(response5)

                const response6 = await axiosClient.post('/calculate/nameChart', fullName);
                console.log('API response:', response6);
                setNameChart(response6?.nameChart)



                const response7 = await axiosClient.post('/calculate/dayChart', birthday);
                console.log('API response:', response7);
                setDayChart(response7)

                console.log(response);
                const matchingDescription = response.descriptionFull;
                if (matchingDescription) {
                    setDescription(matchingDescription);
                } else {
                    setDescription({ description: 'Không có thông tin' });
                }
            } catch (error) {
                console.error('API error:', error);
                // Xử lý lỗi từ API ở đây
            }
        })();
        window.scrollTo(0, 0);
    }, []);

    const chartElements = (
        <div className="chart-container">
            {dayChart?.chart?.map((row, rowIndex) => (
                <div key={rowIndex} className="chart-row">
                    {row.map((number, colIndex) => (
                        <div key={colIndex} className="chart-cell">
                            {number}
                        </div>
                    ))}
                </div>
            ))}
        </div>
    );

    const chartElements2 = (
        <div className="chart-container">
            {nameChart?.chart?.map((row, rowIndex) => (
                <div key={rowIndex} className="chart-row">
                    {row.map((number, colIndex) => (
                        <div key={colIndex} className="chart-cell">
                            {number}
                        </div>
                    ))}
                </div>
            ))}
        </div>
    );

    const columns = [
        { name: "cot147", label: "Cột 147" },
        { name: "cot258", label: "Cột 258" },
        { name: "cot369", label: "Cột 369" }
    ];

    return (
        <Spin spinning={false}>
            <section class="welcome-part-one">
                <div class="container">
                    <div class="welcome-demop102 text-center">
                        <h2>Chào mừng bạn đến với DivineNumerologyHub, nơi mở ra cánh cửa đến thế giới kỳ diệu của thần số học!</h2>
                        <p>Khám phá ý nghĩa sâu sắc của các con số trong các khía cạnh khác nhau của cuộc sống, từ ngày sinh đến tên gọi,<br /> và đắm chìm trong những phương pháp cổ xưa nối liền sự vật chất và tinh thần.<br /></p>
                    </div>
                </div>
            </section>

            <div className="container-home" style={{ fontSize: 26 }}>
                Bạn <span style={{ color: 'blue' }}>{fullName.name}</span>, ngày sinh <span style={{ color: 'red' }}>{birthday.birthDate}</span>
            </div>

            <div className="container-home">
                <div style={{ marginTop: 10 }}>
                    <div>
                        <h2>Số đường đời: {description?.number}</h2>
                        <p className="text-2">Mô tả: {description?.description}</p>
                        <p className="text-2">Ý nghĩa: {description?.meaning}</p>
                        <p className="text-2">Tiềm năng: {description?.potential}</p>
                        <p className="text-2">Thách thức: {description?.challenge}</p>
                        <img
                            style={{ maxWidth: '100%' }}
                            alt="Thần Số Học là gì"
                            src="https://thansovietnam.vn/wp-content/uploads/2021/05/chi-so-duong-doi.png"
                        />
                    </div>

                    <h2>Chỉ số sứ mệnh: {lifePathInfo?.lifePathNumber}</h2>
                    <div className="description-container">
                        <p className="text-2">Mô tả: {lifePathInfo?.description?.description}</p>
                        <p className="text-2">Ưu điểm: {lifePathInfo?.description?.strengths}</p>
                        <p className="text-2">Nhược điểm: {lifePathInfo?.description?.weaknesses}</p>
                        <img
                            style={{ maxWidth: '100%' }}
                            alt="Thần Số Học là gì"
                            src="https://thansovietnam.vn/wp-content/uploads/2021/05/chi-so/so-dinh-menh.png"
                        />
                    </div>
                    <h2>Chỉ số năm cá nhân: {personalYear?.personalYear}</h2>
                    <div className="description-container">
                        <p className="text-2">Mô tả: {personalYear?.description}</p>
                        <img
                            style={{ maxWidth: '100%' }}
                            alt="Thần Số Học là gì"
                            src="https://thansovietnam.vn/wp-content/uploads/2021/05/chi-so/so-nam-ca-nhan.png"
                        />
                    </div>
                    <h2>Chỉ số nợ nghiệp: {karmicDebt?.number}</h2>
                    <div className="description-container">
                        <p className="text-2">Mô tả: {karmicDebt?.description}</p>
                        <p className="text-2">Giải pháp: {karmicDebt?.solution}</p>
                    </div>
                    <h2>4 đỉnh cao của đời người:</h2>
                    <div className="text-2">Đỉnh cao số 1: Đỉnh: {lifePyramid?.lifePyramid?.characteristics2?.peak1} - Tuổi: {lifePyramid?.lifePyramid?.agePeak1}</div>
                    <div className="text-2">Đỉnh cao số 2: Đỉnh: {lifePyramid?.lifePyramid?.characteristics2?.peak2} - Tuổi: {lifePyramid?.lifePyramid?.agePeak2}</div>
                    <div className="text-2">Đỉnh cao số 3: Đỉnh: {lifePyramid?.lifePyramid?.characteristics2?.peak3} - Tuổi: {lifePyramid?.lifePyramid?.agePeak3}</div>
                    <div className="text-2">Đỉnh cao số 4: Đỉnh: {lifePyramid?.lifePyramid?.characteristics2?.peak4} - Tuổi: {lifePyramid?.lifePyramid?.agePeak4}</div>

                    <div className="description-container">
                        <p className="text-2">Mô tả đỉnh cao số 1: {lifePyramid?.lifePyramid?.characteristics?.peak1}</p>
                        <p className="text-2">Mô tả đỉnh cao số 2: {lifePyramid?.lifePyramid?.characteristics?.peak2}</p>
                        <p className="text-2">Mô tả đỉnh cao số 3: {lifePyramid?.lifePyramid?.characteristics?.peak3}</p>
                        <p className="text-2">Mô tả đỉnh cao số 4: {lifePyramid?.lifePyramid?.characteristics?.peak4}</p>
                    </div>
                    <img
                        style={{ maxWidth: '100%' }}
                        alt="Thần Số Học là gì"
                        src="https://thansovietnam.vn/wp-content/uploads/2021/05/chi-so/4-dinh-cuoc-doi.png"
                    />
                    <h2 style={{ marginTop: 20, marginBottom: 20 }}>Biểu đồ họ tên: </h2>
                    <h1>Các cột được chọn</h1>
                    <ul>
                        {columns?.map(column => (
                            nameChart?.[column?.name] && (
                                <li key={column?.name}>
                                    {column?.label === "Cột 147" ?
                                        <div >
                                            <h3>Mũi tên 147: NHÓM 1- LÝ TRÍ, NỀN TẢNG, LOGIC</h3>
                                            <img src="https://i.ibb.co/591L015/anh147.png" alt="anh147" border="0" />
                                            <div class="paragraph">
                                                • Biểu đồ tên của bạn có 1, 4, 7 (Nhóm 1: Lý trí, nền tảng, logic). Bạn có nền tảng tính cách là lý trí, nền tảng, logic. Có nghĩa là dù biểu hiện bên ngoài thế nào thì ẩn sâu bên trong bạn vẫn là người có lý trí. Dù có đưa ra một quyết định nhanh chóng cỡ nào, bạn vẫn luôn có sự phân tích, tính toán, đánh giá. Bạn khá chắc chắn, thực tiễn và thường dựa trên dẫn chứng, thực tế, trải nghiệm để ra quyết định. Khi đã quyết định thì gần như chắc chắn bạn sẽ thực hiện. Bạn thường dễ tiếp nhận các thông tin được trình bày một cách logic. Với nền tảng tính cách này, nếu trong bộ chỉ số có những con số như 1, 4, 7, 8, xu hướng thực tiễn của bạn càng gia tăng, dễ làm tính cách bạn trở nên khô khan.<br />
                                                • Nếu trong nhóm này, số 1 nhiều hơn, sự lý trí và thực tiễn của bạn sẽ theo hướng mục tiêu, hoặc theo hướng lợi ích cho cá nhân bạn.<br />
                                                • Nếu số 4 nhiều hơn, sự lý trí, logic và thực tiễn của bạn theo hướng thông tin, sự thật, sự rõ ràng. Nghĩa là bạn sẽ thiên về tìm kiếm thông tin trong các tình huống, câu chuyện, sự việc; bạn cũng sẽ quy về trách nhiệm và nhiệm vụ mà bạn cần làm; hoặc quy về những điều thiết thực cho gia đình bạn.<br />
                                                • Nếu số 7 chiếm ưu thế, xu hướng của bạn thiên về tìm hiểu bản chất, chân lý, nguyên lý mang tính lý luận, tư tưởng, triết lý nhiều hơn là tính hiện thực của số 4 hoặc tính mục tiêu của số 1.
                                            </div>
                                        </div> : null}
                                    {column?.label === "Cột 258" ?
                                        <div >
                                            <h3>Mũi tên 258: NHÓM 2 – TÌNH CẢM, CẢM XÚC</h3>
                                            <img src="https://i.ibb.co/RjKYXRb/anh258.png" alt="anh258" border="0" />
                                            <div class="paragraph">
                                                •	Biểu đồ tên của bạn có 2, 5, 8 (Nhóm 2: Tình cảm, cảm xúc). Bạn là giàu tình cảm, dễ biểu lộ cảm xúc và khá thất thường. Bạn dễ bị xao động, cuốn theo các câu chuyện, tình huống. Cảm xúc là yếu tố cuốn bạn đi. Khi cảm xúc lên cao, bạn dễ dàng ra quyết định. Nhưng khi cảm xúc tụt xuống, hoặc không còn, bạn rất dễ thay đổi quyết định, từ bỏ. Nếu trong bộ chỉ số có thêm các con số 3, 5, 7, thì bạn càng dễ thay đổi và gia tăng độ thất thường.<br />
                                                •	Nếu trong hàng ngang tình cảm, cảm xúc của bạn, số 2 nhiều hơn thì tình cảm của bạn mang màu sắc của số 2: sự hài hòa, yêu thương, tận tụy. Bạn sẽ nhạy cảm và dễ bị tổn thương, cả nghĩ hơn.<br />
                                                •	Nếu số 5 nhiều hơn, cảm xúc của bạn sẽ theo hướng trải nghiệm. Bạn sẽ dễ bị cuốn theo những gì tươi mới, mạo hiểm, bí hiểm, phiêu lưu, cảm nghiệm giác quan.<br />
                                                •	Nếu số 8 nhiều hơn, cảm xúc của bạn sẽ theo hướng lợi ích, tranh đấu, lớn lao.

                                            </div>
                                        </div> : null}
                                    {column?.label === "Cột 369" ?
                                        <div >
                                            <h3>Mũi tên 369: NHÓM 3 – SÁNG TẠO, Ý TƯỞNG</h3>
                                            <img src="https://i.ibb.co/rsMWkvL/anh369.png" alt="anh369" border="0" />
                                            <div class="paragraph">
                                                •	Biểu đồ tên của bạn có 3, 6, 9 (Nhóm 3: Sáng tạo, ý tưởng) thì nền tảng của bạn thiên về trí não, óc tưởng tượng và sáng tạo. Có nghĩa là tâm trí bạn đầy ắp sự sáng tạo và ý tưởng. Tâm trí bạn có thể bay bổng từ cảnh này sang cảnh khác với muôn vàng màu sắc, hình ảnh, âm thanh. Chỉ cần một thông tin, một chất liệu, bạn có thể tưởng tượng ra nhiều hình ảnh, có thể sáng tạo ra nhiều ý tưởng. Tâm trí bạn phát triển, tức là bạn có sự hiểu biết, đủ linh hoạt và nhận ra cả những sự trừu tượng sâu xa mà không nhất định cần phải chứng thực. Bạn dễ tiếp nhận những điều mới, quan điểm mới, thậm chí, dựa trên những điểm mới đó, bạn còn đi xa hơn nữa<br />
                                                •	Trong hàng ngang 3, 6, 9, nếu số 3 nhiều hơn thì sự sáng tạo, phát triển tâm trí của bạn đi theo hướng hoạt bát nhưng thực tiễn. Bạn có rất nhiều ý tưởng, giải pháp và chúng đều liên quan tới việc đạt được kết quả. Ngoài sự sáng tạo độc đáo mang tính kết quả, bạn còn có thêm màu sắc của sự hài hước, vui vẻ.<br />
                                                •	Nếu số 6 nhiều hơn, sự phát triển tâm trí của bạn đi theo hướng tình cảm, lý tưởng. Bạn hay tưởng tượng tới những hình ảnh hạnh phúc, ấm no, hòa bình, những hình ảnh đẹp một cách lý tưởng.<br />
                                                •	Nếu số 9 nhiều hơn, sự phát triển tâm trí của bạn mang tính trí tuệ hướng tới cộng đồng, con người.
                                            </div>
                                        </div> : null}
                                </li>
                            )
                        ))}
                    </ul>

                    <div style={{ marginBottom: 20 }}>{chartElements2}</div>
                    <img
                        style={{ maxWidth: '100%' }}
                        alt="Thần Số Học là gì"
                        src="https://tracuuthansohoc.com/wp-content/uploads/2021/05/bieu-do-ten-trong-than-so-hoc.jpg"
                    />
                    <h2>Biểu đồ ngày sinh: </h2>
                    <div >
                        {chartElements}
                    </div>
                    <h2 style={{ marginTop: 20 }}>Con số chủ đạo: {dayChart?.coreNumber}</h2>
                    <img
                        style={{ maxWidth: '100%' }}
                        alt="Thần Số Học là gì"
                        src="https://thansovietnam.vn/wp-content/uploads/2021/05/chi-so/so-chu-dao.png"
                    />
                </div>
            </div>

        </Spin >
    );
};

export default Detail;
