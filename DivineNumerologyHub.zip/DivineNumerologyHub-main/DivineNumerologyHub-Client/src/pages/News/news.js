import React, { useState, useEffect, useRef } from "react";
import "./news.css";
import eventApi from "../../apis/eventApi";
import productApi from "../../apis/productApi";
import { useHistory, useParams } from 'react-router-dom';
import { LikeOutlined, DislikeOutlined, HeartOutlined } from '@ant-design/icons';
import { Col, Row, Typography, Form, Spin, Input, Card, notification, Modal, BackTop, message, Avatar, Badge, Rate, List, Descriptions } from "antd";
import axiosClient from "../../apis/axiosClient";
import 'suneditor/dist/css/suneditor.min.css';
import SunEditor from 'suneditor-react';
const { TextArea } = Input;

const { Title, Paragraph } = Typography;

const News = () => {
    const fakeData = [
        {
            id: 1,
            title: "Con Số Chủ Đạo: Số 22/4",
            content:
                "Xem thêm: Tra Cứu Thần Số Học Online Miễn Phí Ý NGHĨA CON SỐ CHỦ ĐẠO SỐ 22/4 Con Số Chủ Đạo 22/4 là những người có tổng ngày sinh là 22, viết là: Số 22/4. ĐẶC ĐIỂM THẦN SỐ HỌC SỐ 22/4 CHỦ ĐẠO Một trong những đặc điểm đáng lưu ý nhất ở những […]",
            imageUrl: "	https://thansohoc.me/wp-content/uploads/2021/02/than-so-hoc-so-22-4-1024x576.jpg", // Thay đổi URL hình ảnh tại đây

        },
        {
            id: 2,
            title: "Con Số Chủ Đạo: Số 11",
            content:
                "Tra Cứu Thần Số Học con số chủ đạo online tại đây Ý NGHĨA CON SỐ CHỦ ĐẠO SỐ 11 Con Số Chủ Đạo 11 là những người có tổng ngày sinh là 29, 38, 47 viết là: 29/11, Số 38/11, Số 47/11. ĐẶC ĐIỂM THẦN SỐ HỌC SỐ 11 CHỦ ĐẠO Người có Số […]",
            imageUrl: "https://thansohoc.me/wp-content/uploads/2021/02/than-so-hoc-so-11-1024x576.jpg",

        },
        {
            id: 3,
            title: "Con Số Chủ Đạo: Số 10",
            content:
                "👉  Tra Cứu Thần Số Học con số chủ đạo online tại đây Ý NGHĨA CON SỐ CHỦ ĐẠO SỐ 10 Con Số Chủ Đạo 10 là những người có tổng ngày sinh là 19, 28, 37, 46, viết là: Số 19/10, Số 28/10, Số 37/10, Số 46/10. ĐẶC ĐIỂM THẦN SỐ HỌC SỐ 10 […]",
            imageUrl: "https://thansohoc.me/wp-content/uploads/2021/02/than-so-hoc-so-10-1024x576.jpg", 

        },
        {
            id: 4,
            title: "Con Số Chủ Đạo: Số 9",
            content:
                "Trong Thần Số Học số 9 là số có tinh thần phụng sự cho đi nhiều nhất. 👉  Tra Cứu Thần Số Học con số chủ đạo online tại đây Ý NGHĨA CON SỐ CHỦ ĐẠO SỐ 9 Con Số Chủ Đạo 9 là những người có tổng ngày sinh là 18, 27, 36, 45, viết là: Số […]",
            imageUrl: "https://thansohoc.me/wp-content/uploads/2021/02/than-so-hoc-so-9-1024x576.jpg", 

        },
        {
            id: 5,
            title: "Con Số Chủ Đạo: Số 8",
            content:
                "Trong Thần Số Học số 8 là số có năng lực điều hành và năng lực về tài chính tốt nhất 👉  Tra Cứu Thần Số Học con số chủ đạo online tại đây Ý NGHĨA CON SỐ CHỦ ĐẠO SỐ 8 Con Số Chủ Đạo 8 là những người có tổng ngày sinh là 17, 26, 35, […]",
            imageUrl: "https://thansohoc.me/wp-content/uploads/2021/02/than-so-hoc-so-8-1024x576.jpg", 

        },
        {
            id: 6,
            title: "Con Số Chủ Đạo: Số 7",
            content:
                "Trong Thần Số Học số 7 là số có sự uyên bác nhất. 👉  Tra Cứu Thần Số Học con số chủ đạo online tại đây Ý NGHĨA CON SỐ CHỦ ĐẠO SỐ 7 Con Số Chủ Đạo 7 là những người có tổng ngày sinh là 16, 25, 34, 43, viết là: Số 16/7, Số 25/7, Số […]",
            imageUrl: "https://thansohoc.me/wp-content/uploads/2021/02/than-so-hoc-so-7-1024x576.jpg", 

        },
        {
            id: 7,
            title: "Con Số Chủ Đạo: Số 6",
            content:
                "Trong Thần Số Học số 6 là số có nhiều tình yêu thương và trách nhiệm nhất. 👉  Tra Cứu Thần Số Học con số chủ đạo online tại đây Ý NGHĨA CON SỐ CHỦ ĐẠO SỐ 6 Con Số Chủ Đạo 6 là những người có tổng ngày sinh là 15, 24, 33, 42, viết là: 15/6, […]",
            imageUrl: "https://thansohoc.me/wp-content/uploads/2021/02/than-so-hoc-so-6-1024x576.jpg",

        },
    ];
    useEffect(() => {

    }, []);

    return (
        <Spin spinning={false}>
            <section class="welcome-part-one">
                <div class="container">
                    <div class="welcome-demop102 text-center">
                        <h2>Chào mừng bạn đến với DivineNumerologyHub, nơi mở ra cánh cửa đến thế giới kỳ diệu của thần số học!</h2>
                        <p>Khám phá ý nghĩa sâu sắc của các con số trong các khía cạnh khác nhau của cuộc sống, từ ngày sinh đến tên gọi,<br /> và đắm chìm trong những phương pháp cổ xưa nối liền sự vật chất và tinh thần.<br /></p>
                    </div>
                </div>
            </section>
            <div className="news-container" style={{marginTop: 20}}>
                <Row gutter={16}>
                    {fakeData.map((item) => (
                        <Col key={item.id} xs={24} sm={12} md={8} lg={6}>
                            <Card
                                className="news-card"
                                hoverable
                                style={{ marginBottom: 16 }}
                                cover={<img alt="Hình ảnh" src={item.imageUrl} />}
                            >
                                <Title level={4}>{item.title}</Title>
                                <Paragraph>{item.content}</Paragraph>
                            </Card>
                        </Col>
                    ))}
                </Row>
            </div>
        </Spin >
    );
};

export default News;
