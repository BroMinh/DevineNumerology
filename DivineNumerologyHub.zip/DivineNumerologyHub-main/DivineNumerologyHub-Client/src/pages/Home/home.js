import React, { useState, useEffect, useRef } from "react";
import "../Home/home.css";
import eventApi from "../../apis/eventApi";
import productApi from "../../apis/productApi";
import { useHistory } from 'react-router-dom';
import { RightOutlined, TagOutlined } from '@ant-design/icons';
import { Col, Form, Button, Input, Spin, Carousel, Card, List, BackTop, Affix, Avatar, Badge, Rate } from "antd";
import axiosClient from "../../apis/axiosClient";


const Home = () => {

    const history = useHistory();

    const onFinish = async (values) => {
        const { fullName, birthday } = values;
        history.push(`/details?fullName=${fullName}&birthday=${birthday}`);

    };

  


    return (
        <Spin spinning={false}>
            <section class="welcome-part-one">
                <div class="container">
                    <div class="welcome-demop102 text-center">
                        <h2>Chào mừng bạn đến với DivineNumerologyHub, nơi mở ra cánh cửa đến thế giới kỳ diệu của thần số học!</h2>
                        <p>Khám phá ý nghĩa sâu sắc của các con số trong các khía cạnh khác nhau của cuộc sống, từ ngày sinh đến tên gọi,<br /> và đắm chìm trong những phương pháp cổ xưa nối liền sự vật chất và tinh thần.<br /></p>
                    </div>
                </div>
            </section>

            <div className="custom-container">
                <Form name="custom-form" onFinish={onFinish}>
                    <div className="custom-btn-container">
                        <Button type="text" className="custom-btn">
                            Họ tên
                        </Button>
                    </div>
                    <div className="custom-input-container">
                        <Form.Item name="fullName">
                            <Input placeholder="Nhập thông tin" className="custom-input" />
                        </Form.Item>
                    </div>
                    <div className="custom-btn-container">
                        <Button type="text" className="custom-btn">
                            Ngày sinh
                        </Button>
                    </div>
                    <div className="custom-input-container">
                        <Form.Item name="birthday">
                            <Input type="date" className="custom-input" />
                        </Form.Item>
                    </div>
                    <div className="custom-btn-container">
                        <Form.Item>
                            <Button type="primary" htmlType="submit" >
                                Xem
                            </Button>
                        </Form.Item>
                    </div>
                </Form>
            </div>

            <div className="container-main">
                <div className="container-2">
                    <h2>Thần số học là gì?</h2>
                    <div>
                        Thần Số Học (Numerology)  là môn học khám phá và nghiên cứu ý nghĩa, biểu tượng của các con số và những ảnh hưởng của nó đối với đời sống con người. Thông qua Họ tên và Ngày sinh của Bạn, Thần Số Học sẽ cho Bạn hiểu biết sâu sắc về con người mình qua những con số, từ tính cách chủ đạo, điểm mạnh, điểm yếu, năng lực, tài năng đặc biết, sứ mệnh, khao khát bên trong của Bạn. Ngoài ra Tra Cứu Thần Số Học còn cho Bạn biết những đỉnh cao thành công hay đỉnh cao thử thách lớn nhất trong cuộc đời Bạn.
                        <div className="center-div">
                            <img
                                alt="Thần Số Học là gì"
                                loading="lazy"
                                src="https://thansohoc.me/wp-content/uploads/2021/08/than-so-hoc-la-gi.jpg"
                            />
                        </div>
                    </div>
                </div>

                <div className="container-2">
                    <h2>Lịch Sử Thần Số Học</h2>
                    <div>
                        Thần số học có lịch sử rất lâu đời (hàng ngàn năm) và các hình thức của nó xuất hiện ở nhiều nền văn hóa. Nhiều ý kiến cho rằng đó là một dạng mê tín dị đoan, lại có nhiều ý kiến xem nó như một môn khoa học tâm linh cao siêu và huyền bí nghiên cứu về ý nghĩa các con số. Không thể phủ nhận ảnh hưởng của Thần số học đến các nền văn hóa là không nhỏ và hàng năm hàng triệu người vẫn tìm hiểu về Thần số học và hàng trăm cuốn sách về vấn đề này cũng được xuất bản trên toàn thế giới

                        Một trong số họ là Pythagoras (thế kỷ 6 trước Công nguyên), nhà triết học, toán học và thiên văn học người Hy Lạp. Ông được coi là “cha đẻ của môn Thần Số Học” vì những đóng góp của ông cho ngành khoa học này cách đây hơn 2500 năm.

                        Tại Việt Nam: vào năm 2020, bà Lê Đỗ Quỳnh Hương là một trong những người có những nghiên cứu rất sâu về thần số học và để theo đúng trường phái của Pythagoras (Pytago) bà đã đổi tên mới cho chuyên ngành này là Nhân số học.                    <div>

                            <div className="center-div">
                                <img
                                    alt="Thần Số Học là gì"
                                    loading="lazy"
                                    src="https://thansohoc.me/wp-content/uploads/2021/08/than-so-hoc-pitago-768x432.jpg"
                                />
                            </div>
                        </div>
                    </div>
                </div>

                <div className="container-2">
                    <h2>Cách Tra Cứu Thần Số Học</h2>
                    <div>
                        "Cách Tra Cứu Thần Số Học là dựa vào Ngày Sinh và Họ Tên Của Bạn. Ngày Sinh thì cộng dồn các con số Vào với nhau, Còn Họ Tên thì ta quy đổi các chữ số trong Họ Tên ra các con số rồi cộng chúng lại với nhau như Ngày sinh. Chữ cái phân biệt Nguyên Âm và Phụ Âm.

                        Ví dụ: Ngày tháng năm sinh dương lịch của bạn là 23/10/1998. Hãy cộng từng con số này lại để được một con số tổng, cụ thể: 2 + 3 + 1 + 0 + 1 + 9 + 9 + 8 = 33. Tiếp tục: 3 + 3 = 6.

                        Vậy con số chủ đạo của bạn là số 6.

                        Ví dụ: bạn tên là TRẦN ANH TUẤN, dựa vào bảng chuyển đổi ở trên ta sẽ có cách tính:

=> T + R + A + N + A + N + H + T + U + A + N

=> 2 + 9 + 1 + 5 + 1 +5 + 8 + 2 + 3 + 1 + 5 = 42 = 4 + 2 = 6

                        Kết quả: Con số định mệnh của Trần Anh Tuấn là 6.

                        Tra Cứu Thần Số Học của Bạn tại đây:  <div>

                            <div className="center-div">
                                <img
                                    alt="Thần Số Học là gì"
                                    loading="lazy"
                                    src="https://thansohoc.me/wp-content/uploads/2021/08/tra-cuu-than-so-hoc-768x410.png"
                                />
                            </div>
                        </div>
                    </div>
                </div>

                <div className="container-2">
                    <h2>Ứng Dụng Thần Số Học</h2>
                    <div>
                        Thần Số Học có thể Ứng dụng cho cá nhân, trường học, gia đình hay doanh nghiệp. Khi mỗi cá nhân thông qua Thần Số Học sẽ hiểu được bản thân mình rất sâu sắc và từ đó sẽ phát huy được năng lực sở trường của mình và cải thiện những điểm yếu. Hơn nữa, Chúng ta có biết được những Bài học hay Sứ Mệnh của mình khi đến cuộc đời này.. Thật sự chỉ từ những thông tin rất cơ bản mà ai cũng có chúng ta có thể biết được rất nhiều "bí mật" của bản thân mà chúng ta không hề biết nếu như không có Thần Số Học. Tóm lại, Ứng dụng Thần Số Học là:

                        Xác định được điểm mạnh và điểm yếu cần khắc phục.
                        Xác định tính cách, khao khát nội tâm.
                        Xác định được bài học, sứ mệnh cuộc đời.
                        Xác định năm, tháng cá nhân và sự kiện tốt xấu đi kèm.
                        Xác định được những cột mốc, những chu kỳ quan trọng trong cuộc đời.
                    </div>
                </div>

                <div className="container-2">
                    <h2>Ý Nghĩa Các Chỉ Số Trong Thần Số Học</h2>
                    <div>
                        Trong Thần Số Học có rất nhiều các chỉ số khác nhau với từng ý nghĩa khác nhau đẻ chúng ta khám phá bản thân mình. Trong đó có những Chỉ số cực kỳ quan trọng và cũng có những chỉ số Ít quan trọng. Trong Phần này chúng tôi xin trình bày hầu hết ý nghĩa các Chỉ số và các biểu đồ trong Thần Số Học để mọi người theo dõi:

                        Để Tra Cứu Thần Số Học Online Miễn Phí của Mình và biêt được các chỉ số, các Bạn hãy nhập thông tin Họ Tên và Ngày Sinh ở đầu trang. <div>

                            <div className="center-div">
                                <img
                                    alt="Thần Số Học là gì"
                                    loading="lazy"
                                    src="https://thansohoc.me/wp-content/uploads/2021/08/y-nghia-cac-chi-so-trong-than-so-hoc-768x432.png"
                                />
                            </div>
                        </div>
                    </div>
                </div>

                <div className="container-2">
                    <h2>Chỉ số Chủ Đạo</h2>
                    <div>
                        Con Số Chủ Đạo theo Thần Số Học (tên tiếng Anh là Your Ruling Number) là con số xâu chuỗi toàn bộ cuộc sống của bạn từ khi bạn sinh ra cho đến lúc bạn buông tay xa lìa cuộc đời này.

                        Định nghĩa: Chỉ số này hé lộ con đường mà bạn sẽ trải qua trong cuộc đời này. Nó cho bạn thấy bạn sẽ gặp phải những trải nghiệm như thế nào, và bạn học được gì sau những trải nghiệm đó. Đây là chỉ số quan trọng nhất khi bạn xem thần số học của mình. Nó cung cấp nhiều thông tin về con người bạn và cuộc đời mà bạn sẽ sống.

                        Cách tính: Cộng tất cả các số trong ngày sinh đầy đủ của bạn thành các số đơn từ 2 đến 11, có trường hợp đặc biệt khi tổng là 22 thì viết là số 22/4.
                    </div>
                </div>

                <div className="container-2">
                    <h2>Chỉ Số Đường Đời</h2>
                    <div>
                        Chỉ Số Đường Đời trong Thần Số Học được có là chỉ số quan trọng nhất, nó có thể được gọi là tên gọi khác của Số Chủ Đạo.

                        Định nghĩa: Chỉ số Đường Đời cho biết đặc điểm, tính cách nổi bật, những nhược điểm trong tính cách, thiên hướng nghề nghiệp phù hợp và bài học lớn nhất trong cuộc đời cần phải học.

                        Cách tính: Cộng tất cả các số trong ngày sinh đầy đủ của bạn thành các số đơn từ 1 đến 9, có trường hợp đặc biệt khi tổng là 11, 22, 33 thì viết là 11/2, 22/4 và 33/6.
                    </div>
                </div>

                <div className="container-2">
                    <h2>Chỉ Số Sứ Mệnh</h2>
                    <div>
                        Định nghĩa: Số Sứ mệnh trong Thần Số Học còn có những tên gọi khác như: Số Định Mệnh, Số Vận Mệnh, chỉ sô này cho biết nhiệm vụ của bạn khi đến với thế giới này là gì? Nó trả lời cho câu hỏi “Tại sao mình lại sinh ra trong cuộc đời” và cuộc đời mình cần phải hướng đến điều gì để có được sự hạnh phúc.

                        Cách tính: Quy tất cả các chữ cái trong Họ tên đầy đủ ra của bạn rồi cộng chúng với nhau đến khi được số rút gọn từ 1 đến 9.
                    </div>
                </div>

                <div className="container-2">
                    <h2>Chỉ Số Thái Độ</h2>
                    <div>
                        Định nghĩa: Số Thái Độ trong Thần Số Học còn có các tên gọi khác như: Chỉ Số Thái Độ Bên Trong là con số thể hiện cách bạn phản ứng với những gì xảy ra trong cuộc đời này như công việc hay trong các mối quan hệ. Số thái độ còn cho bạn thấy biểu hiện ứng xử đầu tiên của bạn khi gặp ai đó. Nếu hiểu được con số này sẽ giúp bạn nhanh chóng ghi điểm trong mắt người khác.

                        Cách tính: Cộng tổng số ngày sinh và số tháng sinh của bạn rồi lấy số rút gọn từ 1 đến 9.

                        <div className="center-div">
                            <img
                                alt="Thần Số Học là gì"
                                loading="lazy"
                                src="https://thansohoc.me/wp-content/uploads/2021/08/chi-so-thai-do-than-so-hoc-768x363.png"
                            />
                        </div>
                    </div>
                </div>

                <div className="container-2">
                    <h2>Chỉ Số Trưởng Thành</h2>
                    <div>
                        Định nghĩa: Chỉ Số Trưởng Thành trong Thần Số Học còn có các tên gói khác như: Chỉ Số Năng Lực Trưởng Thành, Chỉ Số Thành Tựu, Chỉ Số Trung Niên, là con số cho biết năng lực bạn cần rèn luyện để đạt được thành công và hạnh phúc hơn trong cuộc sống ở trong độ tuổi trưởng thành. Bạn càng rèn luyện năng lực này sớm thì khả năng thành công của bạn càng cao bấy nhiêu.

                        Cách Tính: Chỉ số trưởng thành được tính từ tổng của số Đường đời và số Sứ Mệnh rút gọn để lấy số đơn từ 1 đến 9.
                    </div>
                </div>

                <div className="container-2">
                    <h2>Chỉ Số Ngày Sinh</h2>
                    <div>
                        Định nghĩa:  Chỉ số ngày sinh trong Thần Số Học nói cho bạn biết về tài năng đặc biệt và năng lực tự nhiên của bạn. Hãy biết tận dụng tối đa sự ưu ái mà vũ trụ ban tặng cho bạn để thực hiện sứ mệnh của mình

                        Cách Tính: Chỉ số Ngày Sinh được tính từ ngày Sinh rút gọn để lấy số đơn từ 1 đến 11, có ngày sinh 22/4 khi bạn sinh vào ngày 22.
                    </div>
                </div>

                <div className="container-2">
                    <h2>Chỉ Số Linh Hồn</h2>
                    <div>
                        Định nghĩa: Chỉ số linh hồn trong Thần Số Học có các tên gọi khác như: Chỉ Số Động Lực Bên Trong, Chỉ Số Nội Tâm, chủ số này của bạn thể hiện khao khát nội tâm, những mong muốn từ bên trong của bạn sẽ như thế nào. Và khi hiểu được rõ ý nghĩa của con số ấy, bạn sẽ biết được "món ăn tinh thần trong tâm hồn" mình mỗi ngày là gì? Và chỉ khi bạn được là chính mình thì bạn sẽ thấy bình an và hạnh phúc hơn.

                        Cách Tính: Chỉ số Linh Hồn được tính từ tổng chữ cái nguyên âm trong họ tên của bạn rồi quy ra số rút gọn lấy giá trị từ 1 đến 11 và có số 22/4 khi tổng các nguyên âm bằng 22. Các nguyên âm là A, I, E, O, U và có thể là Y.
                    </div>
                </div>

                <div className="container-2">
                    <h2>Chỉ Số Biểu Đạt</h2>
                    <div>
                        Định nghĩa: Chỉ số biểu đạt trong Thần Số Học có rất nhiều các tên gọi khác như Chỉ Số Tính Cách, Chỉ Số Nhân Cách, Chỉ Số Động Lực Bên Ngoài, Chỉ Số Tương Tác, sẽ nói lên được cá tính, phong cách thông qua lời nói, cử chỉ và thái độ của bạn. Hiểu được số tương tác của mình, giúp bạn định vị và củng cố được hình ảnh và bản thân mình. Giúp bạn phát huy cá tính riêng của mình.

                        Cách Tính: Chỉ số Biểu Đạt được tính từ tổng chữ cái phụ âm trong họ tên của bạn rồi quy ra số rút gọn lấy giá trị từ 1 đến 11 và có số 22/4 khi tổng các nguyên âm bằng 22.
                    </div>
                    <div className="center-div">
                        <img
                            alt="Thần Số Học là gì"
                            loading="lazy"
                            src="https://tracuuthansohoc.net/wp-content/uploads/2022/06/chi-so-trong-than-so-hoc-6.jpg.webp"
                        />
                    </div>
                </div>
            </div>


            <BackTop style={{ textAlign: 'right' }} />
        </Spin >
    );
};

export default Home;
