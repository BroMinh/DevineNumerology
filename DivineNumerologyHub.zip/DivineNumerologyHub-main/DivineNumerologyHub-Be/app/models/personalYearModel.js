const mongoose = require('mongoose');

// Định nghĩa mô hình dữ liệu
const PersonalYearSchema = new mongoose.Schema({
  personalYear: Number,
  description: String,
});

// Tạo một mô hình từ schema
const PersonalYear = mongoose.model('PersonalYear', PersonalYearSchema);

// Xuất mô hình để sử dụng ở các tệp khác
module.exports = PersonalYear;
