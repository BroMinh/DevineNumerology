const mongoose = require('mongoose');

const KarmicDebtSchema = new mongoose.Schema({
  number: String, 
  description: String,
  solution: String,
});

const KarmicDebt = mongoose.model('KarmicDebt', KarmicDebtSchema);

module.exports = KarmicDebt;
