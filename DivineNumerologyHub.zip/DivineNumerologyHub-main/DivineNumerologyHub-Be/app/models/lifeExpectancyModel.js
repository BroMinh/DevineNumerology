const mongoose = require('mongoose');

// Định nghĩa schema cho một phần tử trong lifeExpectancy
const lifeExpectancySchema = new mongoose.Schema({
  number: Number,
  description: String,
  meaning: String,
  potential: String,
  challenge: String
});

// Tạo model dựa trên schema
const LifeExpectancyModel = mongoose.model('LifeExpectancy', lifeExpectancySchema);

module.exports = LifeExpectancyModel;
