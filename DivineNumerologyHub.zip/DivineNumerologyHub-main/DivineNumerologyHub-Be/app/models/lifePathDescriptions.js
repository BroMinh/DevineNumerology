// Trong tệp mô hình lifePathDescription.js
const mongoose = require('mongoose');

const LifePathDescriptionSchema = new mongoose.Schema({
  number: Number,
  description: String,
  strengths: String,
  weaknesses: String,
});

module.exports = mongoose.model('LifePathDescription', LifePathDescriptionSchema);
