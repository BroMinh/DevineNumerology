module.exports = Object.freeze({
    PORT: 3100,
    JWT_ACCESS_KEY: 'secretkey',
    ROLE: {
        admin: 'admin',
        client: 'client'
    }
})