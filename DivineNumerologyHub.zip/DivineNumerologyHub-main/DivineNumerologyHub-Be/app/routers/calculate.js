const calculateController = require("../controllers/calculateController");
const router = require("express").Router();
const middleware = require('../utils/middleware');

router.post('/search', calculateController.getLifeExpectancy);
router.post('/lifepath', calculateController.getMissionStatement);
router.post('/personalYear', calculateController.getPersonalYear);
router.post('/karmicDebt', calculateController.getKarmicDebt);
router.post('/lifePyramid', calculateController.getLifePyramid);
router.post('/nameChart', calculateController.calculateNameChart);
router.post('/dayChart', calculateController.calculateDayChart);


module.exports = router;