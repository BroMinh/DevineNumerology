const LifePathDescriptionModel = require('../models/lifePathDescriptions');
const LifeExpectancyModel = require('../models/lifeExpectancyModel');
const PersonalYearModel = require('../models/personalYearModel');
const KarmicDebtModel = require('../models/KarmicDebtModel');

const letterToNumber = {
  A: 1, B: 2, C: 3, D: 4, E: 5, F: 6, G: 7, H: 8, I: 9, J: 1, K: 2, L: 3, M: 4,
  N: 5, O: 6, P: 7, Q: 8, R: 9, S: 1, T: 2, U: 3, V: 4, W: 5, X: 6, Y: 7, Z: 8
};

// Hàm tính Life Path Number từ tên
const calculateLifePath = (name) => {
  const formattedName = name.replace(/\s/g, '').toUpperCase();
  const numbers = formattedName.split('').map(char => letterToNumber[char]);
  let sum = numbers.reduce((total, num) => total + num, 0);

  while (sum > 9) {
    const digits = sum.toString().split('').map(Number);
    sum = digits.reduce((total, digit) => total + digit, 0);
  }

  return sum;
};

// Hàm tính chỉ số năm cá nhân dựa trên ngày và tháng sinh
const calculatePersonalYear = (birthDate) => {
  const dateComponents = birthDate.split('-');

  if (dateComponents.length !== 3) {
    return null; // Định dạng ngày sinh không hợp lệ
  }

  const parsedYear = parseInt(dateComponents[0], 10);
  const parsedMonth = parseInt(dateComponents[1], 10);
  const parsedDay = parseInt(dateComponents[2], 10);

  if (isNaN(parsedYear) || isNaN(parsedMonth) || isNaN(parsedDay)) {
    return null; // Định dạng ngày sinh không hợp lệ
  }

  const currentYear = new Date().getFullYear();
  let personalYear = currentYear + parsedMonth + parsedDay;

  // Đảm bảo personalYear không vượt quá 9 bằng cách lặp lại quá trình cộng dồn
  while (personalYear > 9) {
    const digits = personalYear.toString().split('').map(Number);
    personalYear = digits.reduce((total, digit) => total + digit, 0);
  }

  return personalYear;
};

// Tạo một hàm để tính chỉ số nợ nghiệp từ ngày sinh
const calculateKarmicDebt = (birthDate) => {
  const dateComponents = birthDate.split('-');

  if (dateComponents.length !== 3) {
    return "Định dạng ngày sinh không hợp lệ";
  }

  const parsedYear = parseInt(dateComponents[0], 10);
  const parsedMonth = parseInt(dateComponents[1], 10);
  const parsedDay = parseInt(dateComponents[2], 10);

  if (isNaN(parsedYear) || isNaN(parsedMonth) || isNaN(parsedDay)) {
    return "Định dạng ngày sinh không hợp lệ";
  }

  // Tính tổng ngày, tháng, năm sinh
  const daySum = getDigitSum(parsedDay);
  const monthSum = getDigitSum(parsedMonth);
  const yearSum = getDigitSum(parsedYear);

  const total = daySum + monthSum + yearSum;

  // Kiểm tra nếu tổng này là một trong các chỉ số nợ nghiệp
  const karmicDebts = [13, 14, 16, 19];

  if (karmicDebts.includes(total)) {
    return `${total}/4`;
  }

  return "Không có chỉ số nợ nghiệp";
};

const getDigitSum = (number) => {
  let sum = 0;
  while (number > 0) {
    sum += number % 10;
    number = Math.floor(number / 10);
  }
  return sum;
};

// Hàm để rút gọn một số thành một chữ số duy nhất
const reduceToSingleDigit = (number) => {
  while (number > 9) {
    number = Math.floor(number / 10) + (number % 10);
  }
  return number;
};

// Hàm để lấy tính chất của một con số
const getCharacteristics = (number) => {
  switch (number) {
    case 1:
      return "Là người lãnh đạo và độc lập. Thường tỏ ra quyết đoán và quyền lực.";
    case 2:
      return "Là người hợp tác và nhân từ. Thích làm việc nhóm và thường có khả năng hòa giải.";
    case 3:
      return "Là người sáng tạo và năng động. Thích nghệ thuật và biểu diễn.";
    case 4:
      return "Là người kiên nhẫn và thực tế. Thường xây dựng cơ sở vững chắc và chăm chỉ.";
    case 5:
      return "Là người tự do và phiêu lưu. Thích thay đổi và khám phá.";
    case 6:
      return "Là người yêu thương gia đình và tận tâm. Thường có khả năng chăm sóc người khác.";
    case 7:
      return "Là người tìm kiếm tri thức và sự thật. Thích nghiên cứu và nghiên ngẫm.";
    case 8:
      return "Là người quyền lực và tham vọng. Thường muốn thành công về mặt vật chất.";
    case 9:
      return "Là người thông cảm và hào phóng. Thường quan tâm đến sự phát triển tinh thần.";
    case 11:
      return "Là người mang trong mình sứ mệnh tạo ra sự thay đổi và hiểu biết sâu sắc.";
    case 22:
      return "Là người có khả năng xây dựng cơ sở lớn và ảnh hưởng đối với cộng đồng.";
    default:
      return "Số không có tính chất cụ thể.";
  }
};


// Hàm tính toán Kim tự tháp đời người từ ngày sinh
const calculateLifePyramid = (birthDate) => {
  const dateComponents = birthDate.split('-');

  if (dateComponents.length !== 3) {
    return "Định dạng ngày sinh không hợp lệ";
  }

  const parsedYear = parseInt(dateComponents[0], 10);
  const parsedMonth = parseInt(dateComponents[1], 10);
  const parsedDay = parseInt(dateComponents[2], 10);

  if (isNaN(parsedYear) || isNaN(parsedMonth) || isNaN(parsedDay)) {
    return "Định dạng ngày sinh không hợp lệ";
  }

  // Bước 1: Rút gọn các con số
  const reducedDay = reduceToSingleDigit(parsedDay);
  const reducedMonth = reduceToSingleDigit(parsedMonth);
  const reducedYear = reduceToSingleDigit(parsedYear);

  // Bước 2: Tính các chân đế
  const base1 = reducedMonth;
  const base2 = reducedDay;
  const base3 = reducedYear;

  // Bước 3: Tính đỉnh của hai kim tự tháp đầu tiên
  const peak1 = reduceToSingleDigit(base1 + base2);
  const peak2 = reduceToSingleDigit(base2 + base3);

  // Bước 4: Tính đỉnh của hai kim tự tháp cuối cùng
  const peak3 = peak1 + peak2;
  const peak4 = reduceToSingleDigit(base1 + base3);

  const [day, month, year] = dateComponents.map(component => parseInt(component, 10));

  // Tính tổng của ngày, tháng và năm
  const daySum = day.toString().split('').reduce((sum, digit) => sum + parseInt(digit, 10), 0);
  const monthSum = month.toString().split('').reduce((sum, digit) => sum + parseInt(digit, 10), 0);
  const yearSum = year.toString().split('').reduce((sum, digit) => sum + parseInt(digit, 10), 0);

  // Tính tổng cuối cùng
  const totalSum = daySum + monthSum + yearSum;

  // Kiểm tra nếu tổng cuối cùng là 11 hoặc 22
  if (totalSum === 11 || totalSum === 22) {
    coreNumber = totalSum.toString();
  } else {
    coreNumber = totalSum.toString().split('').reduce((sum, digit) => sum + parseInt(digit, 10), 0);
  }

  // Tính con số chủ đạo
  // Bước 5: Ráp 4 đỉnh với số tuổi
  const agePeak1 = 36 - coreNumber;
  const agePeak2 = agePeak1 + 9;
  const agePeak3 = agePeak2 + 9;
  const agePeak4 = agePeak3 + 9;


  // Bước 6: Tham chiếu tính chất của các con số tại các đỉnh
  const characteristics = {
    peak1: getCharacteristics(peak1),
    peak2: getCharacteristics(peak2),
    peak3: getCharacteristics(peak3),
    peak4: getCharacteristics(peak4),
  };

  const characteristics2 = {
    peak1: peak1,
    peak2: peak2,
    peak3: peak3  >= 11 ? 11 : peak3,
    peak4: peak4  >= 11 ? 11 :peak4,
  };

  console.log(characteristics2)

  return {
    characteristics2,
    characteristics,
    agePeak1,
    agePeak2,
    agePeak3,
    agePeak4,
  };
};

function removeDuplicateChars(str) {
  const charArray = str.split('');
  const uniqueChars = [...new Set(charArray)];
  return uniqueChars.join('');
}

function convertNameToNumber(name) {
  const pythagoreMap = {
    'A': 1, 'J': 1, 'S': 1,
    'B': 2, 'K': 2, 'T': 2,
    'C': 3, 'L': 3, 'U': 3,
    'D': 4, 'M': 4, 'V': 4,
    'E': 5, 'N': 5, 'W': 5,
    'F': 6, 'O': 6, 'X': 6,
    'G': 7, 'P': 7, 'Y': 7,
    'H': 8, 'Q': 8, 'Z': 8,
    'I': 9, 'R': 9
  };

  const nameInUpperCase = name.toUpperCase();
  const nameNumbers = [];

  for (let i = 0; i < nameInUpperCase.length; i++) {
    const char = nameInUpperCase[i];
    if (pythagoreMap[char]) {
      nameNumbers.push(pythagoreMap[char]);
    }
  }
  console.log("---------");
  console.log(nameNumbers);

  const birthdateStr = nameNumbers.join('');

  console.log("---------");

  const chart = [
    ['', '', ''],
    ['', '', ''],
    ['', '', '']
  ];

  for (let i = 0; i < birthdateStr.length; i++) {
    const digit = parseInt(birthdateStr[i]);

    switch (digit) {
      case 0:
        // Số 0 không có vị trí trên biểu đồ
        break;
      case 1:
        chart[2][0] += '1';
        break;
      case 2:
        chart[1][0] += '2';
        break;
      case 3:
        chart[0][0] += '3';
        break;
      case 4:
        chart[2][1] += '4';
        break;
      case 5:
        chart[1][1] += '5';
        break;
      case 6:
        chart[0][1] += '6';
        break;
      case 7:
        chart[2][2] += '7';
        break;
      case 8:
        chart[1][2] += '8';
        break;
      case 9:
        chart[0][2] += '9';
        break;
      default:
        // Xử lý cho các chữ số khác (nếu có)
        break;
    }
  }


  const chuoi147 = chart[2][0] + chart[2][1] + chart[2][2];
  const chuoi258 = chart[1][0] + chart[1][1] + chart[1][2];
  const chuoi369 = chart[0][0] + chart[0][1] + chart[0][2];

  const filteredChuoi147 = removeDuplicateChars(chuoi147);
  const filteredChuoi258 = removeDuplicateChars(chuoi258);
  const filteredChuoi369 = removeDuplicateChars(chuoi369);

  console.log(filteredChuoi147); // Kết quả: "147"
  console.log(filteredChuoi258); // Kết quả: "258"
  console.log(filteredChuoi369); // Kết quả: "369"

  // In biểu đồ sau khi điền số
  console.log('Biểu đồ sau khi điền số:');
  console.log(chart);

  return {
    chart: chart,
    cot147: filteredChuoi147.includes('147'),
    cot258: filteredChuoi147.includes('258'),
    cot369: filteredChuoi147.includes('369'),
  }
}

const calculateDayChart = (birthdate) => {
  const dateComponents = birthdate.split('-');

  if (dateComponents.length !== 3 || dateComponents.some(component => isNaN(component))) {
    return "Định dạng ngày sinh không hợp lệ";
  }

  const [day, month, year] = dateComponents.map(component => parseInt(component, 10));

  // Tính tổng của ngày, tháng và năm
  const daySum = day.toString().split('').reduce((sum, digit) => sum + parseInt(digit, 10), 0);
  const monthSum = month.toString().split('').reduce((sum, digit) => sum + parseInt(digit, 10), 0);
  const yearSum = year.toString().split('').reduce((sum, digit) => sum + parseInt(digit, 10), 0);

  // Tính tổng cuối cùng
  const totalSum = daySum + monthSum + yearSum;

  let coreNumber = 0;
  // Kiểm tra nếu tổng cuối cùng là 11 hoặc 22
  if (totalSum === 11 || totalSum === 22) {
    coreNumber = totalSum.toString();
  } else {
    coreNumber = totalSum.toString().split('').reduce((sum, digit) => sum + parseInt(digit, 10), 0);

  }
  // Tính con số chủ đạo

  // Chuyển ngày sinh thành một chuỗi kí tự
  const birthdateStr = birthdate.replace(/-/g, '');

  // Tạo một mảng 3x3 với giá trị ban đầu là khoảng trắng
  const chart = [
    ['', '', ''],
    ['', '', ''],
    ['', '', '']
  ];

  // Lặp qua từng chữ số trong ngày sinh và điền vào biểu đồ
  for (let i = 0; i < birthdateStr.length; i++) {
    const digit = parseInt(birthdateStr[i]);
    console.log(digit);
    switch (digit) {
      case 0:
        // Số 0 không có vị trí trên biểu đồ
        break;
      case 1:
        // Điền số 1 vào vị trí (2, 0)
        chart[2][0] += '1';
        break;
      case 2:
        chart[1][0] += '2';
        break;
      case 5:
        chart[1][1] += '5';
        break;
      case 8:
        // Điền số 2, 5, 8 vào vị trí (1, 1)
        chart[1][2] += digit.toString();
        break;
      case 3:
        chart[0][0] += '3';
        break;
      case 4:
        chart[2][1] += '4';
        break;
      case 7:
        // Điền số 3, 4, 7 vào vị trí (2, 2)
        chart[2][2] += digit.toString();
        break;
      case 6:
        // Điền số 6 vào vị trí (0, 1)
        chart[0][1] += '6';
        break;
      case 9:
        // Điền số 9 vào vị trí (2, 1)
        chart[0][2] += '9';
        break;
      default:
        // Xử lý cho các chữ số khác (nếu có)
        break;
    }
  }


  return { chart: chart, coreNumber: coreNumber };
};



const cateController = {
  getKarmicDebt: async (req, res) => {
    const { birthDate } = req.body;

    if (!birthDate) {
      return res.status(400).json({ error: "Vui lòng cung cấp ngày sinh" });
    }

    // Tính chỉ số nợ nghiệp từ ngày sinh
    const karmicDebt = calculateKarmicDebt(birthDate);
    const result = await KarmicDebtModel.findOne({ number: karmicDebt });

    res.json(result);
  },
  getPersonalYear: async (req, res) => {
    const { birthDate } = req.body;

    if (!birthDate) {
      return res.status(400).json({ error: "Vui lòng cung cấp ngày sinh" });
    }

    const personalYear = calculatePersonalYear(birthDate);

    if (personalYear === null) {
      return res.status(400).json({ error: "Định dạng ngày sinh không hợp lệ" });
    }

    try {
      // Tìm dữ liệu từ bảng PersonalYear dựa trên personalYear tính toán
      const result = await PersonalYearModel.findOne({ personalYear });

      if (!result) {
        return res.status(404).json({ error: "Không tìm thấy dữ liệu cho personalYear này" });
      }

      res.json(result);
    } catch (error) {
      console.error(`Lỗi khi truy vấn dữ liệu từ cơ sở dữ liệu: ${error}`);
      res.status(500).json({ error: "Lỗi khi truy vấn dữ liệu từ cơ sở dữ liệu" });
    }
  },

  getLifeExpectancy: async (req, res) => {
    const { birthDate } = req.body;
    if(!birthDate){
      return "Không có data";
    }
    const dateComponents = birthDate.split('-');
    const day = parseInt(dateComponents[0], 10);
    const month = parseInt(dateComponents[1], 10);
    const year = parseInt(dateComponents[2], 10);

    if (isNaN(day) || isNaN(month) || isNaN(year)) {
      return res.status(400).json({ error: "Invalid date format" });
    }

    let lifePathNumber = day + month + year;

    while (lifePathNumber > 9) {
      lifePathNumber = String(lifePathNumber)
        .split('')
        .map(Number)
        .reduce((sum, num) => sum + num, 0);
    }

    const description = await LifeExpectancyModel.findOne({ number: lifePathNumber });

    if (!description) {
      return res.status(404).json({ error: 'Không tìm thấy số lifePathNumber' });
    }

    const result = {
      lifePathNumber: lifePathNumber,
      descriptionFull: description
    };

    res.json(result);
  },

  getMissionStatement: async (req, res) => {
    const { name } = req.body;
    if (!name) {
      return res.status(400).json({ error: 'Vui lòng cung cấp tên.' });
    }

    const lifePathNumber = parseInt(calculateLifePath(name), 10);
    console.log(lifePathNumber);

    const description = await LifePathDescriptionModel.findOne({ number: lifePathNumber });

    if (!description) {
      return res.status(404).json({ error: 'Không tìm thấy mô tả cho số sứ mệnh này.' });
    }

    res.json({ lifePathNumber, description });
  },
  getLifePyramid: async (req, res) => {
    const { birthDate } = req.body;

    if (!birthDate) {
      return res.status(400).json({ error: 'Vui lòng cung cấp ngày sinh.' });
    }

    const lifePyramid = calculateLifePyramid(birthDate);

    const response = {
      birthDate,
      lifePyramid,
    };

    res.json(response);
  },
  calculateNameChart: (req, res) => {
    const { name } = req.body;

    if (!name) {
      return res.status(400).json({ error: "Vui lòng cung cấp tên đầy đủ" });
    }

    const nameChart = convertNameToNumber(name);
    res.json({ nameChart });
  },
  calculateDayChart: (req, res) => {
    const { birthDate } = req.body;
    if (!birthDate) {
      return res.status(400).json({ error: "Vui lòng cung cấp ngày sinh" });
    }

    const dayChart = calculateDayChart(birthDate);
    res.json(dayChart);
  },
}

module.exports = cateController;